import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface ChatRequest {
  messages: Array<{
    role: "user" | "assistant" | "system";
    content: string;
  }>;
  petContext?: {
    name: string;
    type: string;
    breed?: string;
    age?: number;
    weight?: number;
    health_conditions?: string[];
    dietary_restrictions?: string[];
    activity_level?: string;
  };
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const openaiApiKey = Deno.env.get("OPENAI_API_KEY");

    if (!openaiApiKey) {
      throw new Error("OpenAI API key not configured");
    }

    const { messages, petContext }: ChatRequest = await req.json();

    const systemPrompt = `You are a professional pet care expert and veterinary advisor for PetMind AI, a comprehensive pet care platform. Your role is to provide accurate, helpful, and compassionate advice about pet care.

Areas of expertise:
- Dog and cat nutrition and dietary needs
- Pet health, wellness, and grooming
- Training techniques and behavior modification
- Exercise and enrichment activities
- Product recommendations from our marketplace
- General pet care best practices

Guidelines:
- Provide specific, actionable advice tailored to the pet's profile
- Be warm, friendly, and encouraging
- When discussing health concerns, always recommend consulting a veterinarian for serious issues
- Suggest relevant products when appropriate
- Keep responses concise but informative (2-4 paragraphs)
- Use the pet's name when known to personalize responses

${petContext ? `Current Pet Profile:
- Name: ${petContext.name}
- Type: ${petContext.type}
- Breed: ${petContext.breed || "Unknown"}
- Age: ${petContext.age ? `${petContext.age} years` : "Unknown"}
- Weight: ${petContext.weight ? `${petContext.weight} lbs` : "Unknown"}
- Activity Level: ${petContext.activity_level || "moderate"}
- Health Conditions: ${petContext.health_conditions?.join(", ") || "None reported"}
- Dietary Restrictions: ${petContext.dietary_restrictions?.join(", ") || "None reported"}` : "No specific pet profile available."}

Remember: You're here to help pet owners make informed decisions and provide the best care for their beloved companions.`;

    const conversationMessages = [
      { role: "system", content: systemPrompt },
      ...messages,
    ];

    const openaiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${openaiApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4o",
        messages: conversationMessages,
        temperature: 0.7,
        max_tokens: 800,
        top_p: 0.9,
        frequency_penalty: 0.3,
        presence_penalty: 0.3,
      }),
    });

    if (!openaiResponse.ok) {
      const errorData = await openaiResponse.json();
      console.error("OpenAI API Error:", errorData);
      throw new Error(`OpenAI API error: ${errorData.error?.message || "Unknown error"}`);
    }

    const data = await openaiResponse.json();
    const aiMessage = data.choices[0]?.message?.content;

    if (!aiMessage) {
      throw new Error("No response from OpenAI");
    }

    return new Response(
      JSON.stringify({
        message: aiMessage,
        model: "gpt-4o",
        usage: data.usage
      }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Edge function error:", error);

    return new Response(
      JSON.stringify({
        error: error.message || "An error occurred processing your request",
        details: error.toString()
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});
