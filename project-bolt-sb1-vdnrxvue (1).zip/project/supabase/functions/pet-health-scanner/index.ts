import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const openAIKey = Deno.env.get("OPENAI_API_KEY");

    if (!openAIKey) {
      return new Response(
        JSON.stringify({ error: "OpenAI API key not configured" }),
        {
          status: 500,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    const { image } = await req.json();

    if (!image) {
      return new Response(
        JSON.stringify({ error: "Image data is required" }),
        {
          status: 400,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    const systemPrompt = `You are a veterinary AI assistant specializing in pet health analysis. Analyze the provided pet image and identify potential health issues.

CRITICAL AREAS TO EXAMINE:
1. Skin Conditions:
   - Skin infections (bacterial, fungal)
   - Rashes and inflammation
   - Hair loss or bald patches (alopecia)
   - Lesions, scabs, or sores
   - Dermatitis or eczema
   - Hot spots

2. Parasites:
   - Signs of fleas (flea dirt, scratching marks)
   - Ticks (visible on skin)
   - Mange (scabby, crusty skin)
   - Lice or mites

3. Eye Health:
   - Eye infections (conjunctivitis, redness)
   - Discharge (clear, yellow, or green)
   - Cloudiness or opacity
   - Swelling or inflammation
   - Cherry eye

4. Coat & Fur:
   - Abnormal shedding
   - Matting or tangling
   - Dry or brittle fur
   - Discoloration
   - Fungal infections (ringworm)

5. Physical Signs:
   - Visible injuries or wounds
   - Swelling or lumps
   - Abnormal body posture
   - Signs of pain or discomfort

DETECTION PRIORITIES:
- Skin infections and irritations
- Flea and tick infestations
- Eye infections
- Hair loss or fungal infections
- Rashes or allergic reactions
- Wounds or injuries

RESPONSE GUIDELINES:
- Be specific about visible observations
- Distinguish between minor and concerning issues
- Always include a veterinary disclaimer
- Provide actionable recommendations
- Use compassionate, non-alarming language
- If the pet looks healthy, provide positive feedback

Return your analysis as a JSON object:
{
  "analysis": "Overall assessment with specific observations about the pet's visible health",
  "possibleIssues": ["Detailed list of specific health concerns identified, e.g., 'Skin infection', 'Flea infestation', 'Eye discharge'"],
  "recommendations": "Clear next steps including when to see a vet (immediately, within a week, etc.) and any at-home care suggestions"
}`;

    const imageUrl = `data:image/jpeg;base64,${image}`;

    const openAIResponse = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${openAIKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4o",
        messages: [
          { role: "system", content: systemPrompt },
          {
            role: "user",
            content: [
              { type: "text", text: "Please analyze this pet image for potential health issues." },
              {
                type: "image_url",
                image_url: {
                  url: imageUrl,
                  detail: "high",
                },
              },
            ],
          },
        ],
        max_tokens: 800,
        temperature: 0.5,
      }),
    });

    if (!openAIResponse.ok) {
      const errorText = await openAIResponse.text();
      console.error("OpenAI API error:", errorText);
      throw new Error("Failed to analyze image");
    }

    const aiData = await openAIResponse.json();
    const responseText = aiData.choices[0].message.content.trim();

    let result;
    try {
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        result = JSON.parse(jsonMatch[0]);
      } else {
        result = JSON.parse(responseText);
      }
    } catch (parseError) {
      console.error("Failed to parse AI response:", responseText);
      result = {
        analysis: responseText,
        possibleIssues: [],
        recommendations: "Please consult a veterinarian for a proper examination."
      };
    }

    return new Response(
      JSON.stringify(result),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Error in pet-health-scanner function:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});
