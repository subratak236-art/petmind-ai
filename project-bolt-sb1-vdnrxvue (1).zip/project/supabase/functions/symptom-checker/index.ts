import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface SymptomRequest {
  symptoms: string;
  petContext?: {
    name: string;
    type: string;
    breed?: string;
    age?: number;
    weight?: number;
    health_conditions?: string[];
  };
}

interface SymptomAnalysis {
  possible_causes: string[];
  care_recommendations: string[];
  product_suggestions: Array<{
    product_type: string;
    reason: string;
  }>;
  urgency_level: 'low' | 'moderate' | 'high' | 'emergency';
  vet_consultation: string;
  general_advice: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { symptoms, petContext }: SymptomRequest = await req.json();

    if (!symptoms || symptoms.trim().length === 0) {
      return new Response(
        JSON.stringify({ error: "Symptoms description is required" }),
        {
          status: 400,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    const openAIKey = Deno.env.get("OPENAI_API_KEY");
    if (!openAIKey) {
      return new Response(
        JSON.stringify({ error: "OpenAI API key not configured" }),
        {
          status: 500,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    const systemPrompt = `You are a professional veterinary assistant providing preliminary symptom analysis for pet owners. Your role is to help pet owners understand potential causes of symptoms and guide them on next steps.

IMPORTANT GUIDELINES:
- Always emphasize that this is NOT a diagnosis and cannot replace professional veterinary care
- Be thorough but cautious in suggesting possible causes
- Clearly indicate when symptoms require immediate veterinary attention
- Provide practical, actionable care recommendations
- Suggest relevant products that might help with comfort or care
- Use clear, compassionate language that reduces anxiety while being informative

URGENCY LEVELS:
- emergency: Life-threatening symptoms requiring immediate veterinary care
- high: Serious symptoms that should be seen within 24 hours
- moderate: Concerning symptoms that should be monitored and seen within 2-3 days
- low: Minor symptoms that can be monitored at home with follow-up if worsening

Remember: The goal is to educate and guide, not to diagnose or replace professional care.`;

    const userPrompt = `Analyze these symptoms and provide comprehensive guidance:

${petContext ? `Pet Information:
- Name: ${petContext.name}
- Type: ${petContext.type}
- Breed: ${petContext.breed || "Unknown"}
- Age: ${petContext.age ? `${petContext.age} years` : "Unknown"}
- Weight: ${petContext.weight ? `${petContext.weight} lbs` : "Unknown"}
- Existing Health Conditions: ${petContext.health_conditions?.join(", ") || "None reported"}
` : "No specific pet information provided."}

Symptoms Reported:
${symptoms}

Please provide a detailed analysis in the following JSON format:
{
  "possible_causes": ["array of 3-5 possible causes, ordered by likelihood"],
  "care_recommendations": ["array of 4-6 specific home care steps the owner can take"],
  "product_suggestions": [
    {
      "product_type": "specific product type (e.g., 'medicated shampoo', 'digestive supplements')",
      "reason": "why this product might help"
    }
  ],
  "urgency_level": "emergency|high|moderate|low",
  "vet_consultation": "specific guidance on when and why to see a vet",
  "general_advice": "2-3 sentence summary with reassurance and key takeaways"
}

Return ONLY the JSON object, no markdown formatting or explanations.`;

    const openAIResponse = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${openAIKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4o",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        temperature: 0.7,
        max_tokens: 1500,
      }),
    });

    if (!openAIResponse.ok) {
      const error = await openAIResponse.text();
      console.error("OpenAI API error:", error);
      return new Response(
        JSON.stringify({ error: "Failed to analyze symptoms" }),
        {
          status: 500,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    const aiData = await openAIResponse.json();
    const responseText = aiData.choices[0].message.content;

    let analysis: SymptomAnalysis;
    try {
      analysis = JSON.parse(responseText);
    } catch (parseError) {
      console.error("Failed to parse AI response:", responseText);
      return new Response(
        JSON.stringify({ error: "Failed to parse symptom analysis" }),
        {
          status: 500,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    return new Response(
      JSON.stringify({ analysis }),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Error in symptom-checker function:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});
