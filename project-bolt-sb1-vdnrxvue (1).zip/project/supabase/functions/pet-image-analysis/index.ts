import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface AnalysisRequest {
  user_id: string;
  pet_id?: string;
  image_data: string;
}

interface AnalysisResult {
  animal_type: string;
  breed: string;
  confidence: number;
  age_range: string;
  body_condition: string;
  health_observations: string[];
  care_recommendations: string[];
  grooming_tips: string[];
  recommended_product_categories: string[];
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const openAIKey = Deno.env.get("OPENAI_API_KEY");

    if (!supabaseUrl || !supabaseServiceKey) {
      throw new Error("Missing Supabase environment variables");
    }

    if (!openAIKey) {
      return new Response(
        JSON.stringify({ error: "OpenAI API key not configured" }),
        {
          status: 500,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const { user_id, pet_id, image_data }: AnalysisRequest = await req.json();

    if (!user_id || !image_data) {
      return new Response(
        JSON.stringify({ error: "user_id and image_data are required" }),
        {
          status: 400,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    const systemPrompt = `You are a veterinary AI assistant specializing in pet image analysis. Analyze the provided pet image and provide detailed insights.

Your analysis should include:
1. Animal type (dog, cat, bird, rabbit, etc.)
2. Possible breed or breed mix
3. Approximate age range (puppy/kitten, young adult, adult, senior)
4. Body condition score (underweight, ideal, overweight, obese)
5. Visible health observations (coat condition, eye clarity, visible injuries, skin issues, etc.)
6. Care recommendations based on what you observe
7. Grooming tips specific to this pet
8. Product categories that would benefit this pet

IMPORTANT GUIDELINES:
- Be specific but acknowledge uncertainty where appropriate
- Focus on observable features only
- Always include a disclaimer that this is not a veterinary diagnosis
- Be supportive and constructive in your recommendations
- If the image is unclear or doesn't contain a pet, politely indicate this

Return your analysis as a JSON object with this structure:
{
  "animal_type": "string",
  "breed": "string (include 'possibly' or 'appears to be' for uncertainty)",
  "confidence": number (0-100),
  "age_range": "string",
  "body_condition": "string",
  "health_observations": ["array of observations"],
  "care_recommendations": ["array of recommendations"],
  "grooming_tips": ["array of grooming tips"],
  "recommended_product_categories": ["array of product categories like 'food', 'toys', 'grooming', 'supplements']
}`;

    const userPrompt = `Please analyze this pet image and provide a comprehensive assessment. Include breed identification, age estimation, body condition, health observations, care recommendations, grooming tips, and suggested product categories.`;

    const openAIResponse = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${openAIKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4o",
        messages: [
          { role: "system", content: systemPrompt },
          {
            role: "user",
            content: [
              { type: "text", text: userPrompt },
              {
                type: "image_url",
                image_url: {
                  url: image_data,
                  detail: "high",
                },
              },
            ],
          },
        ],
        max_tokens: 1000,
        temperature: 0.7,
      }),
    });

    if (!openAIResponse.ok) {
      const errorText = await openAIResponse.text();
      console.error("OpenAI API error:", errorText);
      throw new Error("Failed to analyze image with AI");
    }

    const aiData = await openAIResponse.json();
    const responseText = aiData.choices[0].message.content.trim();

    let analysisResult: AnalysisResult;
    try {
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        analysisResult = JSON.parse(jsonMatch[0]);
      } else {
        analysisResult = JSON.parse(responseText);
      }
    } catch (parseError) {
      console.error("Failed to parse AI response:", responseText);
      throw new Error("Failed to parse AI analysis");
    }

    const { data: imageRecord, error: insertError } = await supabase
      .from("pet_images")
      .insert([
        {
          user_id,
          pet_id: pet_id || null,
          image_url: image_data,
          analysis_result: analysisResult,
        },
      ])
      .select()
      .single();

    if (insertError) {
      console.error("Error inserting image record:", insertError);
    }

    if (pet_id && imageRecord) {
      const { data: existingImages } = await supabase
        .from("pet_images")
        .select("id")
        .eq("pet_id", pet_id);

      if (!existingImages || existingImages.length === 1) {
        await supabase
          .from("pets")
          .update({ primary_image_url: image_data })
          .eq("id", pet_id);
      }
    }

    const { data: products } = await supabase
      .from("products")
      .select("*")
      .in("category", analysisResult.recommended_product_categories || [])
      .order("rating", { ascending: false })
      .limit(6);

    return new Response(
      JSON.stringify({
        analysis: analysisResult,
        image_id: imageRecord?.id,
        recommended_products: products || [],
      }),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Error in pet-image-analysis function:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});
