import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface Pet {
  id: string;
  type: string;
  breed?: string;
  age?: number;
  weight?: number;
  activity_level?: string;
  health_conditions?: string[];
}

interface Product {
  id: string;
  name: string;
  description: string;
  category: string;
  pet_type: string[];
  price: number;
  image_url: string;
  rating: number;
}

interface RecommendationRequest {
  user_id: string;
  pets?: Pet[];
  limit?: number;
  context?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!supabaseUrl || !supabaseServiceKey) {
      throw new Error("Missing Supabase environment variables");
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { user_id, pets, limit = 6, context }: RecommendationRequest = await req.json();

    if (!user_id) {
      return new Response(
        JSON.stringify({ error: "user_id is required" }),
        {
          status: 400,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    const { data: allProducts } = await supabase
      .from("products")
      .select("*")
      .order("rating", { ascending: false });

    const { data: previousOrders } = await supabase
      .from("orders")
      .select(`
        id,
        order_items (
          product_id,
          quantity
        )
      `)
      .eq("user_id", user_id)
      .order("created_at", { ascending: false })
      .limit(5);

    const { data: recentInteractions } = await supabase
      .from("product_interactions")
      .select("product_id, interaction_type")
      .eq("user_id", user_id)
      .order("created_at", { ascending: false })
      .limit(20);

    const { data: chatHistory } = await supabase
      .from("chat_messages")
      .select("content, role")
      .eq("user_id", user_id)
      .order("created_at", { ascending: false })
      .limit(10);

    const openAIKey = Deno.env.get("OPENAI_API_KEY");
    if (!openAIKey) {
      return new Response(
        JSON.stringify({ error: "OpenAI API key not configured" }),
        {
          status: 500,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    const purchasedProductIds = new Set(
      previousOrders?.flatMap(order =>
        order.order_items?.map(item => item.product_id) || []
      ) || []
    );

    const interactedProductIds = new Set(
      recentInteractions?.map(i => i.product_id) || []
    );

    const systemPrompt = `You are an expert pet product recommendation AI for PetMind AI, a premium pet care marketplace. Your role is to analyze user data and suggest the most relevant products that will genuinely benefit their pets.

RECOMMENDATION CRITERIA:
- Prioritize products that match the pet's specific needs (type, breed, age, health conditions)
- Consider user's previous purchases and interactions
- Look for patterns in chat history that indicate needs or concerns
- Balance variety across categories (food, toys, grooming, supplements, training)
- Avoid recommending products the user recently purchased
- Consider activity level and lifestyle factors
- Suggest complementary products

PRODUCT CATEGORIES:
- Dog Food / Cat Food (nutrition, special diets)
- Toys (interactive, chew toys, puzzle toys)
- Grooming (shampoos, brushes, nail care)
- Supplements (joint health, vitamins, digestive)
- Training Accessories (treats, clickers, leashes)
- Health & Wellness (dental care, flea/tick prevention)

OUTPUT FORMAT:
Return a JSON array of product IDs ranked by relevance. Select the ${limit} most relevant products.
Format: ["product-id-1", "product-id-2", ...]`;

    const userPrompt = `Analyze this user's data and recommend the most relevant products:

PET PROFILES:
${pets && pets.length > 0 ? pets.map(pet => `
- ${pet.type} (${pet.breed || 'mixed breed'})
  Age: ${pet.age || 'unknown'} years
  Weight: ${pet.weight || 'unknown'} lbs
  Activity Level: ${pet.activity_level || 'moderate'}
  Health Conditions: ${pet.health_conditions?.join(', ') || 'none reported'}
`).join('\n') : 'No pets registered'}

PREVIOUS PURCHASES:
${purchasedProductIds.size > 0 ? `User has purchased ${purchasedProductIds.size} products previously` : 'No previous purchases'}

RECENT INTERACTIONS:
${recentInteractions && recentInteractions.length > 0
  ? `User has interacted with ${recentInteractions.length} products recently (${recentInteractions.filter(i => i.interaction_type === 'cart_add').length} added to cart)`
  : 'No recent interactions'}

CHAT CONTEXT:
${chatHistory && chatHistory.length > 0
  ? chatHistory.slice(0, 5).map(msg => `${msg.role}: ${msg.content.substring(0, 100)}`).join('\n')
  : 'No chat history'}

${context ? `ADDITIONAL CONTEXT:\n${context}` : ''}

AVAILABLE PRODUCTS:
${allProducts?.map(p => `
ID: ${p.id}
Name: ${p.name}
Category: ${p.category}
Pet Types: ${p.pet_type.join(', ')}
Price: $${p.price}
Rating: ${p.rating}/5
Description: ${p.description?.substring(0, 100) || 'N/A'}
`).join('\n---\n') || 'No products available'}

Recommend the ${limit} most relevant products based on this user's profile and behavior.
Return ONLY a JSON array of product IDs, no explanations or markdown: ["id1", "id2", ...]`;

    const openAIResponse = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${openAIKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4o",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        temperature: 0.7,
        max_tokens: 500,
      }),
    });

    if (!openAIResponse.ok) {
      console.error("OpenAI API error:", await openAIResponse.text());

      const fallbackRecommendations = allProducts
        ?.filter(p => {
          if (!pets || pets.length === 0) return true;
          return pets.some(pet =>
            p.pet_type.length === 0 ||
            p.pet_type.includes(pet.type.toLowerCase())
          );
        })
        .slice(0, limit) || [];

      return new Response(
        JSON.stringify({ recommendations: fallbackRecommendations }),
        {
          status: 200,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    const aiData = await openAIResponse.json();
    const responseText = aiData.choices[0].message.content.trim();

    let recommendedIds: string[];
    try {
      recommendedIds = JSON.parse(responseText);
    } catch (parseError) {
      console.error("Failed to parse AI response:", responseText);

      const fallbackRecommendations = allProducts
        ?.filter(p => {
          if (!pets || pets.length === 0) return true;
          return pets.some(pet =>
            p.pet_type.length === 0 ||
            p.pet_type.includes(pet.type.toLowerCase())
          );
        })
        .slice(0, limit) || [];

      return new Response(
        JSON.stringify({ recommendations: fallbackRecommendations }),
        {
          status: 200,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    const recommendations = recommendedIds
      .map(id => allProducts?.find(p => p.id === id))
      .filter(p => p !== undefined)
      .slice(0, limit);

    return new Response(
      JSON.stringify({ recommendations }),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Error in product-recommendations function:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});
