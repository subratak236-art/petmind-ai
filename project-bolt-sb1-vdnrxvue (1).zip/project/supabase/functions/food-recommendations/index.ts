import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface PetProfile {
  name: string;
  type: string;
  breed?: string;
  age?: number;
  weight?: number;
  health_conditions?: string[];
  dietary_restrictions?: string[];
  activity_level?: string;
}

interface FoodRecommendation {
  product_name: string;
  product_type: string;
  reasoning: string;
  key_benefits: string[];
  feeding_guidelines: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { petProfile }: { petProfile: PetProfile } = await req.json();

    if (!petProfile || !petProfile.type) {
      return new Response(
        JSON.stringify({ error: "Pet profile is required" }),
        {
          status: 400,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    const openAIKey = Deno.env.get("OPENAI_API_KEY");
    if (!openAIKey) {
      return new Response(
        JSON.stringify({ error: "OpenAI API key not configured" }),
        {
          status: 500,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    const systemPrompt = `You are a pet nutrition expert specializing in personalized food recommendations for dogs, cats, and other pets. Your role is to analyze pet profiles and recommend appropriate food products.

Your recommendations should be:
- Science-based and nutritionally sound
- Tailored to the specific pet's needs (age, weight, activity, health)
- Clear about why each food type is recommended
- Practical and actionable

Consider these factors when making recommendations:
- Life stage (puppy/kitten, adult, senior)
- Weight and body condition
- Activity level (affects caloric needs)
- Health conditions (allergies, sensitivities, medical conditions)
- Dietary restrictions
- Breed-specific considerations`;

    const userPrompt = `Analyze this pet profile and provide 3-4 personalized food recommendations:

Pet Profile:
- Name: ${petProfile.name}
- Species: ${petProfile.type}
- Breed: ${petProfile.breed || "Unknown"}
- Age: ${petProfile.age ? `${petProfile.age} years` : "Unknown"}
- Weight: ${petProfile.weight ? `${petProfile.weight} lbs` : "Unknown"}
- Activity Level: ${petProfile.activity_level || "moderate"}
- Health Conditions: ${petProfile.health_conditions?.join(", ") || "None"}
- Dietary Restrictions: ${petProfile.dietary_restrictions?.join(", ") || "None"}

For each recommendation, provide:
1. product_name: A specific type/category of food (e.g., "Premium Adult Dry Food", "Grain-Free Wet Food")
2. product_type: Category (dry_food, wet_food, raw_food, supplement, treat)
3. reasoning: 2-3 sentences explaining WHY this food is ideal for this specific pet
4. key_benefits: Array of 3-4 specific benefits
5. feeding_guidelines: Brief guidance on portion sizes or frequency

Return ONLY a valid JSON array of recommendations. No markdown, no explanation, just the JSON array.`;

    const openAIResponse = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${openAIKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4o",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        temperature: 0.7,
        max_tokens: 1500,
      }),
    });

    if (!openAIResponse.ok) {
      const error = await openAIResponse.text();
      console.error("OpenAI API error:", error);
      return new Response(
        JSON.stringify({ error: "Failed to generate recommendations" }),
        {
          status: 500,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    const aiData = await openAIResponse.json();
    const responseText = aiData.choices[0].message.content;

    let recommendations: FoodRecommendation[];
    try {
      recommendations = JSON.parse(responseText);
    } catch (parseError) {
      console.error("Failed to parse AI response:", responseText);
      return new Response(
        JSON.stringify({ error: "Failed to parse recommendations" }),
        {
          status: 500,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    return new Response(
      JSON.stringify({ recommendations }),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Error in food-recommendations function:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});
