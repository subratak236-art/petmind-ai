/*
  # Add Pet Health Tracking System

  1. New Tables
    - `vaccinations`
      - `id` (uuid, primary key)
      - `pet_id` (uuid, references pets)
      - `user_id` (uuid, references profiles)
      - `vaccine_name` (text, name of vaccine)
      - `date_given` (date, when vaccine was administered)
      - `next_due_date` (date, when next dose is due)
      - `veterinarian_name` (text)
      - `notes` (text)
      - `created_at` (timestamp)
    
    - `weight_records`
      - `id` (uuid, primary key)
      - `pet_id` (uuid, references pets)
      - `user_id` (uuid, references profiles)
      - `date` (date, when weight was recorded)
      - `weight` (decimal, weight in lbs)
      - `notes` (text)
      - `created_at` (timestamp)
    
    - `vet_visits`
      - `id` (uuid, primary key)
      - `pet_id` (uuid, references pets)
      - `user_id` (uuid, references profiles)
      - `visit_date` (date)
      - `veterinarian_name` (text)
      - `clinic_name` (text)
      - `reason` (text, reason for visit)
      - `diagnosis` (text)
      - `treatment` (text)
      - `notes` (text)
      - `created_at` (timestamp)
    
    - `feeding_schedules`
      - `id` (uuid, primary key)
      - `pet_id` (uuid, references pets)
      - `user_id` (uuid, references profiles)
      - `food_type` (text)
      - `amount` (text, e.g., "1 cup", "200g")
      - `feeding_time` (time)
      - `special_instructions` (text)
      - `is_active` (boolean, default true)
      - `created_at` (timestamp)
  
  2. Indexes
    - Add indexes on pet_id and user_id for all tables
    - Add indexes on date fields for efficient querying
  
  3. Security
    - Enable RLS on all new tables
    - Add policies for authenticated users to manage their own pet health data
  
  4. Purpose
    - Track pet vaccinations and send reminders
    - Monitor pet weight trends over time
    - Maintain vet visit history
    - Manage daily feeding schedules
*/

-- Create vaccinations table
CREATE TABLE IF NOT EXISTS vaccinations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pet_id uuid NOT NULL REFERENCES pets(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  vaccine_name text NOT NULL,
  date_given date NOT NULL,
  next_due_date date,
  veterinarian_name text,
  notes text,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_vaccinations_pet_id ON vaccinations(pet_id);
CREATE INDEX IF NOT EXISTS idx_vaccinations_user_id ON vaccinations(user_id);
CREATE INDEX IF NOT EXISTS idx_vaccinations_next_due_date ON vaccinations(next_due_date);

ALTER TABLE vaccinations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own pet vaccinations"
  ON vaccinations FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own pet vaccinations"
  ON vaccinations FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own pet vaccinations"
  ON vaccinations FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own pet vaccinations"
  ON vaccinations FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create weight_records table
CREATE TABLE IF NOT EXISTS weight_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pet_id uuid NOT NULL REFERENCES pets(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  date date NOT NULL,
  weight decimal(6,2) NOT NULL,
  notes text,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_weight_records_pet_id ON weight_records(pet_id);
CREATE INDEX IF NOT EXISTS idx_weight_records_user_id ON weight_records(user_id);
CREATE INDEX IF NOT EXISTS idx_weight_records_date ON weight_records(date);

ALTER TABLE weight_records ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own pet weight records"
  ON weight_records FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own pet weight records"
  ON weight_records FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own pet weight records"
  ON weight_records FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own pet weight records"
  ON weight_records FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create vet_visits table
CREATE TABLE IF NOT EXISTS vet_visits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pet_id uuid NOT NULL REFERENCES pets(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  visit_date date NOT NULL,
  veterinarian_name text,
  clinic_name text,
  reason text NOT NULL,
  diagnosis text,
  treatment text,
  notes text,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_vet_visits_pet_id ON vet_visits(pet_id);
CREATE INDEX IF NOT EXISTS idx_vet_visits_user_id ON vet_visits(user_id);
CREATE INDEX IF NOT EXISTS idx_vet_visits_date ON vet_visits(visit_date);

ALTER TABLE vet_visits ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own pet vet visits"
  ON vet_visits FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own pet vet visits"
  ON vet_visits FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own pet vet visits"
  ON vet_visits FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own pet vet visits"
  ON vet_visits FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create feeding_schedules table
CREATE TABLE IF NOT EXISTS feeding_schedules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pet_id uuid NOT NULL REFERENCES pets(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  food_type text NOT NULL,
  amount text NOT NULL,
  feeding_time time NOT NULL,
  special_instructions text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_feeding_schedules_pet_id ON feeding_schedules(pet_id);
CREATE INDEX IF NOT EXISTS idx_feeding_schedules_user_id ON feeding_schedules(user_id);
CREATE INDEX IF NOT EXISTS idx_feeding_schedules_time ON feeding_schedules(feeding_time);

ALTER TABLE feeding_schedules ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own pet feeding schedules"
  ON feeding_schedules FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own pet feeding schedules"
  ON feeding_schedules FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own pet feeding schedules"
  ON feeding_schedules FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own pet feeding schedules"
  ON feeding_schedules FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);
