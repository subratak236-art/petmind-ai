/*
  # Add Missing Foreign Key Indexes

  1. Purpose
    - Add indexes to all foreign key columns that don't have covering indexes
    - Improves query performance for JOIN operations and foreign key lookups
  
  2. Indexes Added
    - cart_items.product_id
    - chat_messages.pet_id
    - chat_messages.user_id
    - order_items.order_id
    - order_items.product_id
    - orders.user_id
    - pets.user_id
  
  3. Performance Impact
    - Significantly improves JOIN query performance
    - Reduces table scan overhead for foreign key lookups
    - Essential for scaling to larger datasets
*/

-- Add index for cart_items.product_id
CREATE INDEX IF NOT EXISTS idx_cart_items_product_id ON cart_items(product_id);

-- Add indexes for chat_messages foreign keys
CREATE INDEX IF NOT EXISTS idx_chat_messages_pet_id ON chat_messages(pet_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_user_id ON chat_messages(user_id);

-- Add indexes for order_items foreign keys
CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_order_items_product_id ON order_items(product_id);

-- Add index for orders.user_id
CREATE INDEX IF NOT EXISTS idx_orders_user_id ON orders(user_id);

-- Add index for pets.user_id
CREATE INDEX IF NOT EXISTS idx_pets_user_id ON pets(user_id);
