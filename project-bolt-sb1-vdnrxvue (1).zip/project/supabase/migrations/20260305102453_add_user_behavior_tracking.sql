/*
  # Add User Behavior Tracking

  1. New Tables
    - `product_views`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references profiles)
      - `product_id` (uuid, references products)
      - `viewed_at` (timestamp)
    
    - `product_interactions`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references profiles)
      - `product_id` (uuid, references products)
      - `interaction_type` (text: view, cart_add, wishlist)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users to manage their own data
    
  3. Purpose
    - Track user product viewing behavior
    - Track product interactions (cart adds, wishlists)
    - Enable AI-powered personalized recommendations
*/

-- Create product_views table
CREATE TABLE IF NOT EXISTS product_views (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  viewed_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_product_views_user_id ON product_views(user_id);
CREATE INDEX IF NOT EXISTS idx_product_views_product_id ON product_views(product_id);
CREATE INDEX IF NOT EXISTS idx_product_views_viewed_at ON product_views(viewed_at);

ALTER TABLE product_views ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own product views"
  ON product_views FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own product views"
  ON product_views FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create product_interactions table
CREATE TABLE IF NOT EXISTS product_interactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  interaction_type text NOT NULL,
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_interaction_type CHECK (interaction_type IN ('view', 'cart_add', 'wishlist', 'purchase'))
);

CREATE INDEX IF NOT EXISTS idx_product_interactions_user_id ON product_interactions(user_id);
CREATE INDEX IF NOT EXISTS idx_product_interactions_product_id ON product_interactions(product_id);
CREATE INDEX IF NOT EXISTS idx_product_interactions_type ON product_interactions(interaction_type);
CREATE INDEX IF NOT EXISTS idx_product_interactions_created_at ON product_interactions(created_at);

ALTER TABLE product_interactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own product interactions"
  ON product_interactions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own product interactions"
  ON product_interactions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);
