/*
  # Optimize RLS Policies - Auth Function Initialization

  1. Performance Enhancement
    - Wraps auth.uid() calls with SELECT to ensure they execute once per query
    - Without SELECT, auth.uid() re-evaluates for each row, causing severe performance degradation
    - Critical optimization for tables with many rows
    - Follows Supabase best practices for RLS performance

  2. Policies Updated
    - products: "Admins can insert products"
    - products: "Admins can update products"
    - products: "Admins can delete products"
    - orders: "Users and admins can view orders"
    - user_roles: "Users and admins can read roles"

  3. Performance Impact
    - Single evaluation vs per-row evaluation
    - Significant improvement on large result sets
    - Reduces database CPU usage
    - Essential for production-scale applications

  4. Technical Details
    - Pattern: auth.uid() → (SELECT auth.uid())
    - This ensures the auth context is initialized once per statement
    - The subquery is optimized away by PostgreSQL but triggers proper initialization
*/

-- Optimize products table policies
DROP POLICY IF EXISTS "Admins can insert products" ON products;
DROP POLICY IF EXISTS "Admins can update products" ON products;
DROP POLICY IF EXISTS "Admins can delete products" ON products;

CREATE POLICY "Admins can insert products"
  ON products FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles 
      WHERE user_roles.user_id = (SELECT auth.uid())
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Admins can update products"
  ON products FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles 
      WHERE user_roles.user_id = (SELECT auth.uid())
      AND user_roles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles 
      WHERE user_roles.user_id = (SELECT auth.uid())
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Admins can delete products"
  ON products FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles 
      WHERE user_roles.user_id = (SELECT auth.uid())
      AND user_roles.role = 'admin'
    )
  );

-- Optimize orders table policy
DROP POLICY IF EXISTS "Users and admins can view orders" ON orders;

CREATE POLICY "Users and admins can view orders"
  ON orders FOR SELECT
  TO authenticated
  USING (
    (SELECT auth.uid()) = user_id 
    OR 
    EXISTS (
      SELECT 1 FROM user_roles 
      WHERE user_roles.user_id = (SELECT auth.uid())
      AND user_roles.role = 'admin'
    )
  );

-- Optimize user_roles table policy
DROP POLICY IF EXISTS "Users and admins can read roles" ON user_roles;

CREATE POLICY "Users and admins can read roles"
  ON user_roles FOR SELECT
  TO authenticated
  USING (
    (SELECT auth.uid()) = user_id 
    OR 
    EXISTS (
      SELECT 1 FROM user_roles AS ur
      WHERE ur.user_id = (SELECT auth.uid())
      AND ur.role = 'admin'
    )
  );
