/*
  # Add OAuth Support to Profiles

  1. Purpose
    - Add fields to support OAuth authentication providers
    - Store user profile pictures and provider information
    - Ensure seamless OAuth user creation and login

  2. Changes
    - Add `avatar_url` column to store profile pictures from OAuth providers
    - Add `provider` column to track authentication provider (google, apple, facebook, github, email)
    - Add `provider_id` column to store the provider's unique user ID
    - Update existing profiles to have 'email' as default provider

  3. Security
    - No RLS changes needed - existing policies cover new fields
    - Fields are nullable to support both email and OAuth users
*/

-- Add OAuth support columns to profiles table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'avatar_url'
  ) THEN
    ALTER TABLE profiles ADD COLUMN avatar_url text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'provider'
  ) THEN
    ALTER TABLE profiles ADD COLUMN provider text DEFAULT 'email';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'provider_id'
  ) THEN
    ALTER TABLE profiles ADD COLUMN provider_id text;
  END IF;
END $$;

-- Update existing profiles to have 'email' as provider if null
UPDATE profiles SET provider = 'email' WHERE provider IS NULL;
