/*
  # Update Marketplace for INR Currency

  1. Changes
    - Add product_categories table
    - Add price_inr column to products table
    - Add razorpay fields to orders table
    - Update existing products with INR pricing
    - Seed product categories and new products

  2. Security
    - RLS already enabled on existing tables
    - Add RLS for new product_categories table
*/

-- Create product categories table
CREATE TABLE IF NOT EXISTS product_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  image_url text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE product_categories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view product categories"
  ON product_categories FOR SELECT
  USING (true);

-- Add price_inr to products table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'products' AND column_name = 'price_inr'
  ) THEN
    ALTER TABLE products ADD COLUMN price_inr integer DEFAULT 0;
  END IF;
END $$;

-- Add category_id to products table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'products' AND column_name = 'category_id'
  ) THEN
    ALTER TABLE products ADD COLUMN category_id uuid REFERENCES product_categories(id) ON DELETE SET NULL;
  END IF;
END $$;

-- Add razorpay fields to orders table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orders' AND column_name = 'razorpay_order_id'
  ) THEN
    ALTER TABLE orders ADD COLUMN razorpay_order_id text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orders' AND column_name = 'razorpay_payment_id'
  ) THEN
    ALTER TABLE orders ADD COLUMN razorpay_payment_id text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orders' AND column_name = 'amount_inr'
  ) THEN
    ALTER TABLE orders ADD COLUMN amount_inr integer DEFAULT 0;
  END IF;
END $$;

-- Add price_inr to order_items table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'order_items' AND column_name = 'price_inr'
  ) THEN
    ALTER TABLE order_items ADD COLUMN price_inr integer DEFAULT 0;
  END IF;
END $$;

-- Seed product categories
INSERT INTO product_categories (name, slug, image_url) VALUES
  ('Dog Food', 'dog-food', 'https://images.pexels.com/photos/5732444/pexels-photo-5732444.jpeg'),
  ('Cat Food', 'cat-food', 'https://images.pexels.com/photos/3659498/pexels-photo-3659498.jpeg'),
  ('Pet Toys', 'pet-toys', 'https://images.pexels.com/photos/9422144/pexels-photo-9422144.jpeg'),
  ('Pet Health & Grooming', 'pet-health-grooming', 'https://images.pexels.com/photos/6816861/pexels-photo-6816861.jpeg')
ON CONFLICT (slug) DO NOTHING;

-- Update existing products with INR pricing
UPDATE products SET price_inr = (price * 8300)::integer WHERE price_inr = 0;

-- Add new products with INR pricing
DO $$
DECLARE
  v_dog_food_cat_id uuid;
  v_cat_food_cat_id uuid;
  v_pet_toys_cat_id uuid;
  v_health_cat_id uuid;
BEGIN
  SELECT id INTO v_dog_food_cat_id FROM product_categories WHERE slug = 'dog-food';
  SELECT id INTO v_cat_food_cat_id FROM product_categories WHERE slug = 'cat-food';
  SELECT id INTO v_pet_toys_cat_id FROM product_categories WHERE slug = 'pet-toys';
  SELECT id INTO v_health_cat_id FROM product_categories WHERE slug = 'pet-health-grooming';

  INSERT INTO products (category_id, name, description, price, price_inr, category, pet_type, image_url, stock, rating)
  SELECT v_dog_food_cat_id, 'Royal Canin Adult Dog Food', 'Premium nutrition for adult dogs. Complete and balanced diet with optimal protein content.', 12.00, 99900, 'food', ARRAY['dog'], 'https://images.pexels.com/photos/5732444/pexels-photo-5732444.jpeg', 50, 4.8
  WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Royal Canin Adult Dog Food');

  INSERT INTO products (category_id, name, description, price, price_inr, category, pet_type, image_url, stock, rating)
  SELECT v_dog_food_cat_id, 'Pedigree Chicken Dog Food', 'Nutritious chicken flavored food for healthy and active dogs.', 7.20, 59900, 'food', ARRAY['dog'], 'https://images.pexels.com/photos/5731873/pexels-photo-5731873.jpeg', 75, 4.5
  WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Pedigree Chicken Dog Food');

  INSERT INTO products (category_id, name, description, price, price_inr, category, pet_type, image_url, stock, rating)
  SELECT v_cat_food_cat_id, 'Whiskas Adult Cat Food', 'Delicious and nutritious meals for adult cats with essential vitamins.', 6.00, 49900, 'food', ARRAY['cat'], 'https://images.pexels.com/photos/3659498/pexels-photo-3659498.jpeg', 60, 4.6
  WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Whiskas Adult Cat Food');

  INSERT INTO products (category_id, name, description, price, price_inr, category, pet_type, image_url, stock, rating)
  SELECT v_pet_toys_cat_id, 'Rubber Chew Bone Toy', 'Durable rubber chew toy for dogs. Helps with dental health and keeps pets entertained.', 2.40, 19900, 'toys', ARRAY['dog'], 'https://images.pexels.com/photos/5256709/pexels-photo-5256709.jpeg', 100, 4.7
  WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Rubber Chew Bone Toy');

  INSERT INTO products (category_id, name, description, price, price_inr, category, pet_type, image_url, stock, rating)
  SELECT v_pet_toys_cat_id, 'Cat Feather Teaser Toy', 'Interactive feather wand toy that cats love to chase and play with.', 1.80, 14900, 'toys', ARRAY['cat'], 'https://images.pexels.com/photos/1440387/pexels-photo-1440387.jpeg', 80, 4.4
  WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Cat Feather Teaser Toy');

  INSERT INTO products (category_id, name, description, price, price_inr, category, pet_type, image_url, stock, rating)
  SELECT v_health_cat_id, 'Dog Shampoo', 'Gentle shampoo for dogs with natural ingredients. Keeps coat shiny and healthy.', 3.60, 29900, 'health', ARRAY['dog'], 'https://images.pexels.com/photos/6816861/pexels-photo-6816861.jpeg', 45, 4.5
  WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Dog Shampoo');

  INSERT INTO products (category_id, name, description, price, price_inr, category, pet_type, image_url, stock, rating)
  SELECT v_health_cat_id, 'Tick & Flea Spray', 'Effective tick and flea prevention spray. Safe for pets and long-lasting protection.', 4.80, 39900, 'health', ARRAY['dog', 'cat'], 'https://images.pexels.com/photos/5255253/pexels-photo-5255253.jpeg', 35, 4.6
  WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Tick & Flea Spray');
END $$;

-- Create index for category_id
CREATE INDEX IF NOT EXISTS idx_products_category_id ON products(category_id);
