/*
  # Drop Unused Database Indexes

  1. Security & Performance
    - Removes unused indexes that are not being utilized
    - Reduces database maintenance overhead
    - Improves write performance by eliminating unnecessary index updates
    - Frees up storage space

  2. Indexes Being Removed
    - Product views indexes (user_id, product_id, viewed_at)
    - Product interactions indexes (user_id, product_id, type, created_at)
    - Pet images indexes (pet_id, user_id, created_at)
    - Vaccinations indexes (pet_id, user_id, next_due_date)
    - Weight records indexes (pet_id, user_id, date)
    - Vet visits indexes (pet_id, user_id, date)
    - Feeding schedules indexes (pet_id, user_id, time)
    - Cart items indexes (product_id)
    - Chat messages indexes (pet_id, user_id)
    - Order items indexes (order_id, product_id)
    - Orders indexes (user_id)
    - Pets indexes (user_id)

  3. Important Notes
    - Foreign key constraints remain intact
    - Indexes can be recreated if needed in the future
    - Primary key indexes are preserved
*/

-- Drop product_views indexes
DROP INDEX IF EXISTS idx_product_views_user_id;
DROP INDEX IF EXISTS idx_product_views_product_id;
DROP INDEX IF EXISTS idx_product_views_viewed_at;

-- Drop product_interactions indexes
DROP INDEX IF EXISTS idx_product_interactions_user_id;
DROP INDEX IF EXISTS idx_product_interactions_product_id;
DROP INDEX IF EXISTS idx_product_interactions_type;
DROP INDEX IF EXISTS idx_product_interactions_created_at;

-- Drop pet_images indexes
DROP INDEX IF EXISTS idx_pet_images_pet_id;
DROP INDEX IF EXISTS idx_pet_images_user_id;
DROP INDEX IF EXISTS idx_pet_images_created_at;

-- Drop vaccinations indexes
DROP INDEX IF EXISTS idx_vaccinations_pet_id;
DROP INDEX IF EXISTS idx_vaccinations_user_id;
DROP INDEX IF EXISTS idx_vaccinations_next_due_date;

-- Drop weight_records indexes
DROP INDEX IF EXISTS idx_weight_records_pet_id;
DROP INDEX IF EXISTS idx_weight_records_user_id;
DROP INDEX IF EXISTS idx_weight_records_date;

-- Drop vet_visits indexes
DROP INDEX IF EXISTS idx_vet_visits_pet_id;
DROP INDEX IF EXISTS idx_vet_visits_user_id;
DROP INDEX IF EXISTS idx_vet_visits_date;

-- Drop feeding_schedules indexes
DROP INDEX IF EXISTS idx_feeding_schedules_pet_id;
DROP INDEX IF EXISTS idx_feeding_schedules_user_id;
DROP INDEX IF EXISTS idx_feeding_schedules_time;

-- Drop cart_items indexes
DROP INDEX IF EXISTS idx_cart_items_product_id;

-- Drop chat_messages indexes
DROP INDEX IF EXISTS idx_chat_messages_pet_id;
DROP INDEX IF EXISTS idx_chat_messages_user_id;

-- Drop order_items indexes
DROP INDEX IF EXISTS idx_order_items_order_id;
DROP INDEX IF EXISTS idx_order_items_product_id;

-- Drop orders indexes
DROP INDEX IF EXISTS idx_orders_user_id;

-- Drop pets indexes
DROP INDEX IF EXISTS idx_pets_user_id;
