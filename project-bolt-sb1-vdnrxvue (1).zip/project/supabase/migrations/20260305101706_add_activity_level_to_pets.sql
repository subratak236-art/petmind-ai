/*
  # Add Activity Level to Pets Table

  1. Changes
    - Add `activity_level` column to `pets` table
      - Type: text (low, moderate, high)
      - Default: 'moderate'
      - Used for personalized food recommendations
  
  2. Notes
    - Activity level helps determine caloric needs
    - Integrates with AI food recommendation system
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'pets' AND column_name = 'activity_level'
  ) THEN
    ALTER TABLE pets ADD COLUMN activity_level text DEFAULT 'moderate';
  END IF;
END $$;