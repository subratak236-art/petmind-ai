/*
  # Fix Function Search Path (With CASCADE)

  1. Purpose
    - Fix the is_admin function to have an immutable search path
    - Prevents security issues from search path manipulation
    - Recreate dependent policies after function update
  
  2. Changes
    - Drop existing is_admin function and dependent policies
    - Recreate function with explicit schema references
    - Recreate all dependent policies
*/

-- Drop existing function with cascade to remove dependent policies
DROP FUNCTION IF EXISTS is_admin() CASCADE;

-- Recreate function with secure search path and explicit schema references
CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = ''
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 
    FROM public.user_roles
    WHERE user_roles.user_id = auth.uid()
    AND user_roles.role = 'admin'
  );
$$;

-- Recreate dependent policies for products table
CREATE POLICY "Admins can manage products"
  ON products
  FOR ALL
  TO authenticated
  USING (is_admin())
  WITH CHECK (is_admin());

-- Recreate dependent policies for orders table
CREATE POLICY "Admins can view all orders"
  ON orders
  FOR SELECT
  TO authenticated
  USING (is_admin());

CREATE POLICY "Admins can update orders"
  ON orders
  FOR UPDATE
  TO authenticated
  USING (is_admin())
  WITH CHECK (is_admin());
