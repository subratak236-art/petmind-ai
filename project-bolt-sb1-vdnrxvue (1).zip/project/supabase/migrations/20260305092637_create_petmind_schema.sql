/*
  # PetMind AI Database Schema

  ## Overview
  Complete database schema for PetMind AI platform including user profiles, pets, chat history,
  products, shopping cart, and order management.

  ## New Tables

  ### 1. profiles
  - `id` (uuid, primary key, references auth.users)
  - `email` (text, not null)
  - `full_name` (text)
  - `created_at` (timestamptz, default now())
  - `updated_at` (timestamptz, default now())

  ### 2. pets
  - `id` (uuid, primary key)
  - `user_id` (uuid, references profiles)
  - `name` (text, not null)
  - `type` (text, not null) - dog, cat, bird, etc.
  - `breed` (text)
  - `age` (integer)
  - `weight` (decimal)
  - `health_conditions` (text[])
  - `dietary_restrictions` (text[])
  - `avatar_url` (text)
  - `created_at` (timestamptz, default now())
  - `updated_at` (timestamptz, default now())

  ### 3. chat_messages
  - `id` (uuid, primary key)
  - `user_id` (uuid, references profiles)
  - `pet_id` (uuid, references pets, nullable)
  - `role` (text, not null) - 'user' or 'assistant'
  - `content` (text, not null)
  - `created_at` (timestamptz, default now())

  ### 4. products
  - `id` (uuid, primary key)
  - `name` (text, not null)
  - `description` (text)
  - `category` (text, not null) - food, toys, accessories, health, etc.
  - `pet_type` (text[]) - applicable pet types
  - `price` (decimal, not null)
  - `image_url` (text)
  - `stock` (integer, default 0)
  - `rating` (decimal)
  - `created_at` (timestamptz, default now())

  ### 5. cart_items
  - `id` (uuid, primary key)
  - `user_id` (uuid, references profiles)
  - `product_id` (uuid, references products)
  - `quantity` (integer, not null, default 1)
  - `created_at` (timestamptz, default now())
  - `updated_at` (timestamptz, default now())

  ### 6. orders
  - `id` (uuid, primary key)
  - `user_id` (uuid, references profiles)
  - `total_amount` (decimal, not null)
  - `status` (text, default 'pending') - pending, processing, shipped, delivered, cancelled
  - `shipping_address` (jsonb)
  - `created_at` (timestamptz, default now())
  - `updated_at` (timestamptz, default now())

  ### 7. order_items
  - `id` (uuid, primary key)
  - `order_id` (uuid, references orders)
  - `product_id` (uuid, references products)
  - `quantity` (integer, not null)
  - `price_at_purchase` (decimal, not null)
  - `created_at` (timestamptz, default now())

  ## Security
  - Row Level Security (RLS) enabled on all tables
  - Policies restrict users to their own data
  - Products table readable by all authenticated users
  - Cart and orders restricted to owner only

  ## Important Notes
  1. All user-specific data protected by RLS
  2. Products seeded with sample data
  3. Chat history maintained per user and pet
  4. Order history immutable after creation
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  email text NOT NULL,
  full_name text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Create pets table
CREATE TABLE IF NOT EXISTS pets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  name text NOT NULL,
  type text NOT NULL,
  breed text,
  age integer,
  weight decimal,
  health_conditions text[] DEFAULT '{}',
  dietary_restrictions text[] DEFAULT '{}',
  avatar_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE pets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own pets"
  ON pets FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own pets"
  ON pets FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own pets"
  ON pets FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own pets"
  ON pets FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create chat_messages table
CREATE TABLE IF NOT EXISTS chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  pet_id uuid REFERENCES pets(id) ON DELETE SET NULL,
  role text NOT NULL,
  content text NOT NULL,
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_role CHECK (role IN ('user', 'assistant'))
);

ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own chat messages"
  ON chat_messages FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own chat messages"
  ON chat_messages FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own chat messages"
  ON chat_messages FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create products table
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  category text NOT NULL,
  pet_type text[] DEFAULT '{}',
  price decimal NOT NULL,
  image_url text,
  stock integer DEFAULT 0,
  rating decimal DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view products"
  ON products FOR SELECT
  TO authenticated
  USING (true);

-- Create cart_items table
CREATE TABLE IF NOT EXISTS cart_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  quantity integer NOT NULL DEFAULT 1,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, product_id)
);

ALTER TABLE cart_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own cart"
  ON cart_items FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert into own cart"
  ON cart_items FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own cart"
  ON cart_items FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete from own cart"
  ON cart_items FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  total_amount decimal NOT NULL,
  status text DEFAULT 'pending',
  shipping_address jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_status CHECK (status IN ('pending', 'processing', 'shipped', 'completed', 'cancelled'))
);

ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own orders"
  ON orders FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own orders"
  ON orders FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create order_items table
CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES products(id),
  quantity integer NOT NULL,
  price_at_purchase decimal NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own order items"
  ON order_items FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_items.order_id
      AND orders.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert own order items"
  ON order_items FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_items.order_id
      AND orders.user_id = auth.uid()
    )
  );

-- Insert sample products
INSERT INTO products (name, description, category, pet_type, price, image_url, stock, rating) VALUES
  ('Premium Dog Food', 'High-quality nutritious dog food for all breeds', 'food', ARRAY['dog'], 49.99, 'https://images.pexels.com/photos/1482193/pexels-photo-1482193.jpeg', 100, 4.8),
  ('Cat Scratching Post', 'Durable scratching post with toys', 'accessories', ARRAY['cat'], 34.99, 'https://images.pexels.com/photos/1741205/pexels-photo-1741205.jpeg', 50, 4.5),
  ('Interactive Dog Toy', 'Puzzle toy to keep your dog entertained', 'toys', ARRAY['dog'], 24.99, 'https://images.pexels.com/photos/1629781/pexels-photo-1629781.jpeg', 75, 4.7),
  ('Cat Litter Premium', 'Odor control cat litter, 20lb bag', 'accessories', ARRAY['cat'], 19.99, 'https://images.pexels.com/photos/1440387/pexels-photo-1440387.jpeg', 120, 4.6),
  ('Pet Multivitamin', 'Complete vitamins for dogs and cats', 'health', ARRAY['dog', 'cat'], 29.99, 'https://images.pexels.com/photos/5731873/pexels-photo-5731873.jpeg', 80, 4.9),
  ('Comfortable Pet Bed', 'Soft orthopedic pet bed for all sizes', 'accessories', ARRAY['dog', 'cat'], 59.99, 'https://images.pexels.com/photos/4587998/pexels-photo-4587998.jpeg', 40, 4.7),
  ('Cat Wet Food Variety Pack', '12-pack gourmet cat food', 'food', ARRAY['cat'], 32.99, 'https://images.pexels.com/photos/1359307/pexels-photo-1359307.jpeg', 90, 4.8),
  ('Dog Leash & Collar Set', 'Durable nylon leash and collar combo', 'accessories', ARRAY['dog'], 19.99, 'https://images.pexels.com/photos/825949/pexels-photo-825949.jpeg', 60, 4.4),
  ('Cat Feather Wand', 'Interactive feather toy for cats', 'toys', ARRAY['cat'], 12.99, 'https://images.pexels.com/photos/1741205/pexels-photo-1741205.jpeg', 100, 4.6),
  ('Dog Dental Chews', 'Dental health treats for dogs', 'health', ARRAY['dog'], 27.99, 'https://images.pexels.com/photos/1458916/pexels-photo-1458916.jpeg', 110, 4.7)
ON CONFLICT DO NOTHING;