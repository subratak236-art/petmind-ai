/*
  # Fix Multiple Permissive RLS Policies

  1. Security Enhancement
    - Consolidates multiple permissive policies into single policies
    - Prevents security confusion from overlapping policies
    - Maintains same access control logic with clearer implementation

  2. Tables Updated
    - orders: Combine admin and user view policies
    - products: Combine admin and public view policies
    - user_roles: Combine admin and user read policies

  3. Policy Changes
    - Uses OR logic to combine conditions in single policy
    - Maintains backward compatibility with existing access patterns
    - Improves policy evaluation performance
*/

-- Fix orders table: Combine "Admins can view all orders" and "Users can view own orders"
DROP POLICY IF EXISTS "Admins can view all orders" ON orders;
DROP POLICY IF EXISTS "Users can view own orders" ON orders;

CREATE POLICY "Users and admins can view orders"
  ON orders FOR SELECT
  TO authenticated
  USING (
    auth.uid() = user_id 
    OR 
    EXISTS (
      SELECT 1 FROM user_roles 
      WHERE user_roles.user_id = auth.uid() 
      AND user_roles.role = 'admin'
    )
  );

-- Fix products table: Combine "Admins can manage products" and "Anyone can view products"
DROP POLICY IF EXISTS "Admins can manage products" ON products;
DROP POLICY IF EXISTS "Anyone can view products" ON products;

CREATE POLICY "Anyone can view products"
  ON products FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can insert products"
  ON products FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles 
      WHERE user_roles.user_id = auth.uid() 
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Admins can update products"
  ON products FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles 
      WHERE user_roles.user_id = auth.uid() 
      AND user_roles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles 
      WHERE user_roles.user_id = auth.uid() 
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Admins can delete products"
  ON products FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles 
      WHERE user_roles.user_id = auth.uid() 
      AND user_roles.role = 'admin'
    )
  );

-- Fix user_roles table: Combine "Admins can read all roles" and "Users can read own role"
DROP POLICY IF EXISTS "Admins can read all roles" ON user_roles;
DROP POLICY IF EXISTS "Users can read own role" ON user_roles;

CREATE POLICY "Users and admins can read roles"
  ON user_roles FOR SELECT
  TO authenticated
  USING (
    auth.uid() = user_id 
    OR 
    EXISTS (
      SELECT 1 FROM user_roles AS ur
      WHERE ur.user_id = auth.uid() 
      AND ur.role = 'admin'
    )
  );
