/*
  # Add Foreign Key Indexes for Performance

  1. Performance Enhancement
    - Adds indexes to all foreign key columns that were missing them
    - Significantly improves JOIN performance and query execution
    - Speeds up referential integrity checks
    - Essential for optimal database performance at scale

  2. Tables and Indexes
    - cart_items: product_id
    - chat_messages: pet_id, user_id
    - feeding_schedules: pet_id, user_id
    - order_items: order_id, product_id
    - orders: user_id
    - pet_images: pet_id, user_id
    - pets: user_id
    - product_interactions: product_id, user_id
    - product_views: product_id, user_id
    - vaccinations: pet_id, user_id
    - vet_visits: pet_id, user_id
    - weight_records: pet_id, user_id

  3. Important Notes
    - Foreign keys without indexes can cause significant performance degradation
    - These indexes are critical for JOIN operations and cascading operations
    - Composite indexes may be added in future for specific query patterns
*/

-- Add index for cart_items foreign keys
CREATE INDEX IF NOT EXISTS idx_cart_items_product_id ON cart_items(product_id);

-- Add indexes for chat_messages foreign keys
CREATE INDEX IF NOT EXISTS idx_chat_messages_pet_id ON chat_messages(pet_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_user_id ON chat_messages(user_id);

-- Add indexes for feeding_schedules foreign keys
CREATE INDEX IF NOT EXISTS idx_feeding_schedules_pet_id ON feeding_schedules(pet_id);
CREATE INDEX IF NOT EXISTS idx_feeding_schedules_user_id ON feeding_schedules(user_id);

-- Add indexes for order_items foreign keys
CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_order_items_product_id ON order_items(product_id);

-- Add index for orders foreign key
CREATE INDEX IF NOT EXISTS idx_orders_user_id ON orders(user_id);

-- Add indexes for pet_images foreign keys
CREATE INDEX IF NOT EXISTS idx_pet_images_pet_id ON pet_images(pet_id);
CREATE INDEX IF NOT EXISTS idx_pet_images_user_id ON pet_images(user_id);

-- Add index for pets foreign key
CREATE INDEX IF NOT EXISTS idx_pets_user_id ON pets(user_id);

-- Add indexes for product_interactions foreign keys
CREATE INDEX IF NOT EXISTS idx_product_interactions_product_id ON product_interactions(product_id);
CREATE INDEX IF NOT EXISTS idx_product_interactions_user_id ON product_interactions(user_id);

-- Add indexes for product_views foreign keys
CREATE INDEX IF NOT EXISTS idx_product_views_product_id ON product_views(product_id);
CREATE INDEX IF NOT EXISTS idx_product_views_user_id ON product_views(user_id);

-- Add indexes for vaccinations foreign keys
CREATE INDEX IF NOT EXISTS idx_vaccinations_pet_id ON vaccinations(pet_id);
CREATE INDEX IF NOT EXISTS idx_vaccinations_user_id ON vaccinations(user_id);

-- Add indexes for vet_visits foreign keys
CREATE INDEX IF NOT EXISTS idx_vet_visits_pet_id ON vet_visits(pet_id);
CREATE INDEX IF NOT EXISTS idx_vet_visits_user_id ON vet_visits(user_id);

-- Add indexes for weight_records foreign keys
CREATE INDEX IF NOT EXISTS idx_weight_records_pet_id ON weight_records(pet_id);
CREATE INDEX IF NOT EXISTS idx_weight_records_user_id ON weight_records(user_id);
