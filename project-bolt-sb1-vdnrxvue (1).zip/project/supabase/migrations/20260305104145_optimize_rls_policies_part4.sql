/*
  # Optimize RLS Policies - Part 4 (Health Tracking Tables)

  1. Purpose
    - Optimize RLS policies for health tracking tables
    - Ensures consistent performance for vaccination, weight, vet visit, and feeding data
  
  2. Tables Updated
    - pet_images
    - vaccinations
    - weight_records
    - vet_visits
    - feeding_schedules
  
  3. Changes
    - Drop existing policies
    - Recreate with optimized auth function calls wrapped in SELECT
*/

-- Optimize pet_images table policies
DROP POLICY IF EXISTS "Users can view own pet images" ON pet_images;
DROP POLICY IF EXISTS "Users can insert own pet images" ON pet_images;
DROP POLICY IF EXISTS "Users can update own pet images" ON pet_images;
DROP POLICY IF EXISTS "Users can delete own pet images" ON pet_images;

CREATE POLICY "Users can view own pet images"
  ON pet_images FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users can insert own pet images"
  ON pet_images FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can update own pet images"
  ON pet_images FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can delete own pet images"
  ON pet_images FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- Optimize vaccinations table policies
DROP POLICY IF EXISTS "Users can view own pet vaccinations" ON vaccinations;
DROP POLICY IF EXISTS "Users can insert own pet vaccinations" ON vaccinations;
DROP POLICY IF EXISTS "Users can update own pet vaccinations" ON vaccinations;
DROP POLICY IF EXISTS "Users can delete own pet vaccinations" ON vaccinations;

CREATE POLICY "Users can view own pet vaccinations"
  ON vaccinations FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users can insert own pet vaccinations"
  ON vaccinations FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can update own pet vaccinations"
  ON vaccinations FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can delete own pet vaccinations"
  ON vaccinations FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- Optimize weight_records table policies
DROP POLICY IF EXISTS "Users can view own pet weight records" ON weight_records;
DROP POLICY IF EXISTS "Users can insert own pet weight records" ON weight_records;
DROP POLICY IF EXISTS "Users can update own pet weight records" ON weight_records;
DROP POLICY IF EXISTS "Users can delete own pet weight records" ON weight_records;

CREATE POLICY "Users can view own pet weight records"
  ON weight_records FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users can insert own pet weight records"
  ON weight_records FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can update own pet weight records"
  ON weight_records FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can delete own pet weight records"
  ON weight_records FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- Optimize vet_visits table policies
DROP POLICY IF EXISTS "Users can view own pet vet visits" ON vet_visits;
DROP POLICY IF EXISTS "Users can insert own pet vet visits" ON vet_visits;
DROP POLICY IF EXISTS "Users can update own pet vet visits" ON vet_visits;
DROP POLICY IF EXISTS "Users can delete own pet vet visits" ON vet_visits;

CREATE POLICY "Users can view own pet vet visits"
  ON vet_visits FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users can insert own pet vet visits"
  ON vet_visits FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can update own pet vet visits"
  ON vet_visits FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can delete own pet vet visits"
  ON vet_visits FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- Optimize feeding_schedules table policies
DROP POLICY IF EXISTS "Users can view own pet feeding schedules" ON feeding_schedules;
DROP POLICY IF EXISTS "Users can insert own pet feeding schedules" ON feeding_schedules;
DROP POLICY IF EXISTS "Users can update own pet feeding schedules" ON feeding_schedules;
DROP POLICY IF EXISTS "Users can delete own pet feeding schedules" ON feeding_schedules;

CREATE POLICY "Users can view own pet feeding schedules"
  ON feeding_schedules FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users can insert own pet feeding schedules"
  ON feeding_schedules FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can update own pet feeding schedules"
  ON feeding_schedules FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can delete own pet feeding schedules"
  ON feeding_schedules FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);
