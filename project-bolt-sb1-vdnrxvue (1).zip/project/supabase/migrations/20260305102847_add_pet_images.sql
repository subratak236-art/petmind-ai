/*
  # Add Pet Image Storage

  1. New Tables
    - `pet_images`
      - `id` (uuid, primary key)
      - `pet_id` (uuid, references pets)
      - `user_id` (uuid, references profiles)
      - `image_url` (text, base64 encoded image)
      - `analysis_result` (jsonb, stores AI analysis)
      - `created_at` (timestamp)
    
  2. Modifications
    - Add `primary_image_url` to pets table for quick access
    
  3. Security
    - Enable RLS on pet_images table
    - Add policies for authenticated users to manage their own pet images
    
  4. Purpose
    - Store pet photos uploaded by users
    - Store AI analysis results from image recognition
    - Enable pet health tracking through visual analysis
*/

-- Create pet_images table
CREATE TABLE IF NOT EXISTS pet_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pet_id uuid NOT NULL REFERENCES pets(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  image_url text NOT NULL,
  analysis_result jsonb,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_pet_images_pet_id ON pet_images(pet_id);
CREATE INDEX IF NOT EXISTS idx_pet_images_user_id ON pet_images(user_id);
CREATE INDEX IF NOT EXISTS idx_pet_images_created_at ON pet_images(created_at);

ALTER TABLE pet_images ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own pet images"
  ON pet_images FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own pet images"
  ON pet_images FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own pet images"
  ON pet_images FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own pet images"
  ON pet_images FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Add primary_image_url to pets table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'pets' AND column_name = 'primary_image_url'
  ) THEN
    ALTER TABLE pets ADD COLUMN primary_image_url text;
  END IF;
END $$;
