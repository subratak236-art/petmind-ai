/*
  # Optimize RLS Policies - Part 3 (User Roles, Product Views/Interactions)

  1. Purpose
    - Continue optimizing RLS policies with (select auth.uid())
    - Improves performance for admin and analytics queries
  
  2. Tables Updated
    - user_roles
    - product_views
    - product_interactions
  
  3. Changes
    - Drop existing policies
    - Recreate with optimized auth function calls
*/

-- Optimize user_roles table policies
DROP POLICY IF EXISTS "Users can read own role" ON user_roles;
DROP POLICY IF EXISTS "Admins can read all roles" ON user_roles;
DROP POLICY IF EXISTS "Admins can insert roles" ON user_roles;
DROP POLICY IF EXISTS "Admins can update roles" ON user_roles;

CREATE POLICY "Users can read own role"
  ON user_roles FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Admins can read all roles"
  ON user_roles FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = (select auth.uid())
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Admins can insert roles"
  ON user_roles FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = (select auth.uid())
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Admins can update roles"
  ON user_roles FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = (select auth.uid())
      AND user_roles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = (select auth.uid())
      AND user_roles.role = 'admin'
    )
  );

-- Optimize product_views table policies
DROP POLICY IF EXISTS "Users can view own product views" ON product_views;
DROP POLICY IF EXISTS "Users can insert own product views" ON product_views;

CREATE POLICY "Users can view own product views"
  ON product_views FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users can insert own product views"
  ON product_views FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

-- Optimize product_interactions table policies
DROP POLICY IF EXISTS "Users can view own product interactions" ON product_interactions;
DROP POLICY IF EXISTS "Users can insert own product interactions" ON product_interactions;

CREATE POLICY "Users can view own product interactions"
  ON product_interactions FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users can insert own product interactions"
  ON product_interactions FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);
